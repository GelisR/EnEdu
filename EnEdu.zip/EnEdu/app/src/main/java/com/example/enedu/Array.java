package com.example.enedu;

public class Array {

    final int[] images = {
            R.drawable.lvl1_qvz1,
            R.drawable.lvl1_qvz2,
            R.drawable.lvl1_qvz3,
            R.drawable.lvl1_qvz4,
            R.drawable.lvl1_qvz5,
            R.drawable.lvl1_qvz6,
            R.drawable.lvl1_qvz7,
            R.drawable.lvl1_qvz8,
    };
    final int[] images2 = {
            R.drawable.lvl2_1,
            R.drawable.lvl2_2,
            R.drawable.lvl2_3,
            R.drawable.lvl2_4,
            R.drawable.lvl2_5,
            R.drawable.lvl2_6,
            R.drawable.lvl2_7,
            R.drawable.lvl2_8,
            R.drawable.lvl2_9,
    };
    final int[] images3 = {
            R.drawable.lvl3_1,
            R.drawable.lvl3_2,
            R.drawable.lvl3_3,
            R.drawable.lvl3_4,
            R.drawable.lvl3_5,
            R.drawable.lvl3_6,
            R.drawable.lvl3_7,
            R.drawable.lvl3_8,
            R.drawable.lvl3_9,
    };
    final int[] images4 = {
            R.drawable.lvl4_1,
            R.drawable.lvl4_2,
            R.drawable.lvl4_3,
            R.drawable.lvl4_4,
            R.drawable.lvl4_5,
            R.drawable.lvl4_6,
            R.drawable.lvl4_7,
            R.drawable.lvl4_8,
            R.drawable.lvl4_9,
    };
    final int[] images5 = {
            R.drawable.lvl5_1,
            R.drawable.lvl5_2,
            R.drawable.lvl5_3,
            R.drawable.lvl5_4,
            R.drawable.lvl5_5,
            R.drawable.lvl5_6,
            R.drawable.lvl5_7,
            R.drawable.lvl5_8,
            R.drawable.lvl5_9,
    };
    final int[] images6 = {
            R.drawable.lvl6_1,
            R.drawable.lvl6_2,
            R.drawable.lvl6_3,
            R.drawable.lvl6_4,
            R.drawable.lvl6_5,
            R.drawable.lvl6_6,
            R.drawable.lvl6_7,
            R.drawable.lvl6_8,
            R.drawable.lvl6_9,
    };
    final int[] images7 = {
            R.drawable.lvl7_1,
            R.drawable.lvl7_2,
            R.drawable.lvl7_3,
            R.drawable.lvl7_4,
            R.drawable.lvl7_5,
            R.drawable.lvl7_6,
            R.drawable.lvl7_7,
            R.drawable.lvl7_8,
            R.drawable.lvl7_9,
    };
    final int[] images8 = {
            R.drawable.lvl8_1,
            R.drawable.lvl8_2,
            R.drawable.lvl8_3,
            R.drawable.lvl8_4,
            R.drawable.lvl8_5,
            R.drawable.lvl8_6,
            R.drawable.lvl8_7,
            R.drawable.lvl8_8,
            R.drawable.lvl8_9,
    };
    final int[] images9 = {
            R.drawable.lvl9_1,
            R.drawable.lvl9_2,
            R.drawable.lvl9_3,
            R.drawable.lvl9_4,
            R.drawable.lvl9_5,
            R.drawable.lvl9_6,
            R.drawable.lvl9_7,
            R.drawable.lvl9_8,
            R.drawable.lvl9_9,
    };
    final int[] images10 = {
            R.drawable.lvl10_1,
            R.drawable.lvl10_2,
            R.drawable.lvl10_3,
            R.drawable.lvl10_4,
            R.drawable.lvl10_5,
            R.drawable.lvl10_6,
            R.drawable.lvl10_7,
            R.drawable.lvl10_8,
            R.drawable.lvl10_9,
    };


    final int[] quest1={
            R.string.lvll_qvz1,
            R.string.lvll_qvz2,
            R.string.lvll_qvz3,
            R.string.lvll_qvz4,
            R.string.lvll_qvz5,
            R.string.lvll_qvz6,
            R.string.lvll_qvz7,
            R.string.lvll_qvz8,
    };

    final int[] f1_Quest1={
            R.string.lvll_F1qvz1,
            R.string.lvll_F1qvz2,
            R.string.lvll_F1qvz3,
            R.string.lvll_F1qvz4,
            R.string.lvll_F1qvz5,
            R.string.lvll_F1qvz6,
            R.string.lvll_F1qvz7,
            R.string.lvll_F1qvz8,
    };

    final int[] f2_Quest1={
            R.string.lvll_F2qvz1,
            R.string.lvll_F2qvz2,
            R.string.lvll_F2qvz3,
            R.string.lvll_F2qvz4,
            R.string.lvll_F2qvz5,
            R.string.lvll_F2qvz6,
            R.string.lvll_F2qvz7,
            R.string.lvll_F2qvz8,
    };

    final int[] f3_Quest1={
            R.string.lvll_F3qvz1,
            R.string.lvll_F3qvz2,
            R.string.lvll_F3qvz3,
            R.string.lvll_F3qvz4,
            R.string.lvll_F3qvz5,
            R.string.lvll_F3qvz6,
            R.string.lvll_F3qvz7,
            R.string.lvll_F3qvz8,
    };
    //lvl2
    final int[] quest2={
            R.string.lvl2_qvz1,
            R.string.lvl2_qvz2,
            R.string.lvl2_qvz3,
            R.string.lvl2_qvz4,
            R.string.lvl2_qvz5,
            R.string.lvl2_qvz6,
            R.string.lvl2_qvz7,
            R.string.lvl2_qvz8,
            R.string.lvl2_qvz9,
    };

    final int[] f1_Quest2={
            R.string.lvl2_F1qvz1,
            R.string.lvl2_F1qvz2,
            R.string.lvl2_F1qvz3,
            R.string.lvl2_F1qvz4,
            R.string.lvl2_F1qvz5,
            R.string.lvl2_F1qvz6,
            R.string.lvl2_F1qvz7,
            R.string.lvl2_F1qvz8,
            R.string.lvl2_F1qvz9,
    };

    final int[] f2_Quest2={
            R.string.lvl2_F2qvz1,
            R.string.lvl2_F2qvz2,
            R.string.lvl2_F2qvz3,
            R.string.lvl2_F2qvz4,
            R.string.lvl2_F2qvz5,
            R.string.lvl2_F2qvz6,
            R.string.lvl2_F2qvz7,
            R.string.lvl2_F2qvz8,
            R.string.lvl2_F2qvz9,
    };

    final int[] f3_Quest2={
            R.string.lvl2_F3qvz1,
            R.string.lvl2_F3qvz2,
            R.string.lvl2_F3qvz3,
            R.string.lvl2_F3qvz4,
            R.string.lvl2_F3qvz5,
            R.string.lvl2_F3qvz6,
            R.string.lvl2_F3qvz7,
            R.string.lvl2_F3qvz8,
            R.string.lvl2_F3qvz9,
    };
//lvl3
    final int[] quest3={
            R.string.lvl3_qvz1,
            R.string.lvl3_qvz2,
            R.string.lvl3_qvz3,
            R.string.lvl3_qvz4,
            R.string.lvl3_qvz5,
            R.string.lvl3_qvz6,
            R.string.lvl3_qvz7,
            R.string.lvl3_qvz8,
            R.string.lvl3_qvz9,
    };

    final int[] f1_Quest3={
            R.string.lvl3_F1qvz1,
            R.string.lvl3_F1qvz2,
            R.string.lvl3_F1qvz3,
            R.string.lvl3_F1qvz4,
            R.string.lvl3_F1qvz5,
            R.string.lvl3_F1qvz6,
            R.string.lvl3_F1qvz7,
            R.string.lvl3_F1qvz8,
            R.string.lvl3_F1qvz9,
    };

    final int[] f2_Quest3={
            R.string.lvl3_F2qvz1,
            R.string.lvl3_F2qvz2,
            R.string.lvl3_F2qvz3,
            R.string.lvl3_F2qvz4,
            R.string.lvl3_F2qvz5,
            R.string.lvl3_F2qvz6,
            R.string.lvl3_F2qvz7,
            R.string.lvl3_F2qvz8,
            R.string.lvl3_F2qvz9,
    };

    final int[] f3_Quest3={
            R.string.lvl3_F3qvz1,
            R.string.lvl3_F3qvz2,
            R.string.lvl3_F3qvz3,
            R.string.lvl3_F3qvz4,
            R.string.lvl3_F3qvz5,
            R.string.lvl3_F3qvz6,
            R.string.lvl3_F3qvz7,
            R.string.lvl3_F3qvz8,
            R.string.lvl3_F3qvz9,
    };
//lvl4
    final int[] quest4={
            R.string.lvl4_qvz1,
            R.string.lvl4_qvz2,
            R.string.lvl4_qvz3,
            R.string.lvl4_qvz4,
            R.string.lvl4_qvz5,
            R.string.lvl4_qvz6,
            R.string.lvl4_qvz7,
            R.string.lvl4_qvz8,
            R.string.lvl4_qvz9,
    };

    final int[] f1_Quest4={
            R.string.lvl4_F1qvz1,
            R.string.lvl4_F1qvz2,
            R.string.lvl4_F1qvz3,
            R.string.lvl4_F1qvz4,
            R.string.lvl4_F1qvz5,
            R.string.lvl4_F1qvz6,
            R.string.lvl4_F1qvz7,
            R.string.lvl4_F1qvz8,
            R.string.lvl4_F1qvz9,
    };

    final int[] f2_Quest4={
            R.string.lvl4_F2qvz1,
            R.string.lvl4_F2qvz2,
            R.string.lvl4_F2qvz3,
            R.string.lvl4_F2qvz4,
            R.string.lvl4_F2qvz5,
            R.string.lvl4_F2qvz6,
            R.string.lvl4_F2qvz7,
            R.string.lvl4_F2qvz8,
            R.string.lvl4_F2qvz9,
    };

    final int[] f3_Quest4={
            R.string.lvl4_F3qvz1,
            R.string.lvl4_F3qvz2,
            R.string.lvl4_F3qvz3,
            R.string.lvl4_F3qvz4,
            R.string.lvl4_F3qvz5,
            R.string.lvl4_F3qvz6,
            R.string.lvl4_F3qvz7,
            R.string.lvl4_F3qvz8,
            R.string.lvl4_F3qvz9,
    };
    //lvl5
    final int[] quest5={
            R.string.lvl5_qvz1,
            R.string.lvl5_qvz2,
            R.string.lvl5_qvz3,
            R.string.lvl5_qvz4,
            R.string.lvl5_qvz5,
            R.string.lvl5_qvz6,
            R.string.lvl5_qvz7,
            R.string.lvl5_qvz8,
            R.string.lvl5_qvz9,
    };

    final int[] f1_Quest5={
            R.string.lvl5_F1qvz1,
            R.string.lvl5_F1qvz2,
            R.string.lvl5_F1qvz3,
            R.string.lvl5_F1qvz4,
            R.string.lvl5_F1qvz5,
            R.string.lvl5_F1qvz6,
            R.string.lvl5_F1qvz7,
            R.string.lvl5_F1qvz8,
            R.string.lvl5_F1qvz9,
    };

    final int[] f2_Quest5={
            R.string.lvl5_F2qvz1,
            R.string.lvl5_F2qvz2,
            R.string.lvl5_F2qvz3,
            R.string.lvl5_F2qvz4,
            R.string.lvl5_F2qvz5,
            R.string.lvl5_F2qvz6,
            R.string.lvl5_F2qvz7,
            R.string.lvl5_F2qvz8,
            R.string.lvl5_F2qvz9,
    };

    final int[] f3_Quest5={
            R.string.lvl5_F3qvz1,
            R.string.lvl5_F3qvz2,
            R.string.lvl5_F3qvz3,
            R.string.lvl5_F3qvz4,
            R.string.lvl5_F3qvz5,
            R.string.lvl5_F3qvz6,
            R.string.lvl5_F3qvz7,
            R.string.lvl5_F3qvz8,
            R.string.lvl5_F3qvz9,
    };
    //lvl6
    final int[] quest6={
            R.string.lvl6_qvz1,
            R.string.lvl6_qvz2,
            R.string.lvl6_qvz3,
            R.string.lvl6_qvz4,
            R.string.lvl6_qvz5,
            R.string.lvl6_qvz6,
            R.string.lvl6_qvz7,
            R.string.lvl6_qvz8,
            R.string.lvl6_qvz9,
    };

    final int[] f1_Quest6={
            R.string.lvl6_F1qvz1,
            R.string.lvl6_F1qvz2,
            R.string.lvl6_F1qvz3,
            R.string.lvl6_F1qvz4,
            R.string.lvl6_F1qvz5,
            R.string.lvl6_F1qvz6,
            R.string.lvl6_F1qvz7,
            R.string.lvl6_F1qvz8,
            R.string.lvl6_F1qvz9,
    };

    final int[] f2_Quest6={
            R.string.lvl6_F2qvz1,
            R.string.lvl6_F2qvz2,
            R.string.lvl6_F2qvz3,
            R.string.lvl6_F2qvz4,
            R.string.lvl6_F2qvz5,
            R.string.lvl6_F2qvz6,
            R.string.lvl6_F2qvz7,
            R.string.lvl6_F2qvz8,
            R.string.lvl6_F2qvz9,
    };

    final int[] f3_Quest6={
            R.string.lvl6_F3qvz1,
            R.string.lvl6_F3qvz2,
            R.string.lvl6_F3qvz3,
            R.string.lvl6_F3qvz4,
            R.string.lvl6_F3qvz5,
            R.string.lvl6_F3qvz6,
            R.string.lvl6_F3qvz7,
            R.string.lvl6_F3qvz8,
            R.string.lvl6_F3qvz9,
    };
    //lvl7
    final int[] quest7={
            R.string.lvl7_qvz1,
            R.string.lvl7_qvz2,
            R.string.lvl7_qvz3,
            R.string.lvl7_qvz4,
            R.string.lvl7_qvz5,
            R.string.lvl7_qvz6,
            R.string.lvl7_qvz7,
            R.string.lvl7_qvz8,
            R.string.lvl7_qvz9,
    };

    final int[] f1_Quest7={
            R.string.lvl7_F1qvz1,
            R.string.lvl7_F1qvz2,
            R.string.lvl7_F1qvz3,
            R.string.lvl7_F1qvz4,
            R.string.lvl7_F1qvz5,
            R.string.lvl7_F1qvz6,
            R.string.lvl7_F1qvz7,
            R.string.lvl7_F1qvz8,
            R.string.lvl7_F1qvz9,
    };

    final int[] f2_Quest7={
            R.string.lvl7_F2qvz1,
            R.string.lvl7_F2qvz2,
            R.string.lvl7_F2qvz3,
            R.string.lvl7_F2qvz4,
            R.string.lvl7_F2qvz5,
            R.string.lvl7_F2qvz6,
            R.string.lvl7_F2qvz7,
            R.string.lvl7_F2qvz8,
            R.string.lvl7_F2qvz9,
    };

    final int[] f3_Quest7={
            R.string.lvl7_F3qvz1,
            R.string.lvl7_F3qvz2,
            R.string.lvl7_F3qvz3,
            R.string.lvl7_F3qvz4,
            R.string.lvl7_F3qvz5,
            R.string.lvl7_F3qvz6,
            R.string.lvl7_F3qvz7,
            R.string.lvl7_F3qvz8,
            R.string.lvl7_F3qvz9,
    };
    //lvl8
    final int[] quest8={
            R.string.lvl8_qvz1,
            R.string.lvl8_qvz2,
            R.string.lvl8_qvz3,
            R.string.lvl8_qvz4,
            R.string.lvl8_qvz5,
            R.string.lvl8_qvz6,
            R.string.lvl8_qvz7,
            R.string.lvl8_qvz8,
            R.string.lvl8_qvz9,
    };

    final int[] f1_Quest8={
            R.string.lvl8_F1qvz1,
            R.string.lvl8_F1qvz2,
            R.string.lvl8_F1qvz3,
            R.string.lvl8_F1qvz4,
            R.string.lvl8_F1qvz5,
            R.string.lvl8_F1qvz6,
            R.string.lvl8_F1qvz7,
            R.string.lvl8_F1qvz8,
            R.string.lvl8_F1qvz9,
    };

    final int[] f2_Quest8={
            R.string.lvl8_F2qvz1,
            R.string.lvl8_F2qvz2,
            R.string.lvl8_F2qvz3,
            R.string.lvl8_F2qvz4,
            R.string.lvl8_F2qvz5,
            R.string.lvl8_F2qvz6,
            R.string.lvl8_F2qvz7,
            R.string.lvl8_F2qvz8,
            R.string.lvl8_F2qvz9,
    };

    final int[] f3_Quest8={
            R.string.lvl8_F3qvz1,
            R.string.lvl8_F3qvz2,
            R.string.lvl8_F3qvz3,
            R.string.lvl8_F3qvz4,
            R.string.lvl8_F3qvz5,
            R.string.lvl8_F3qvz6,
            R.string.lvl8_F3qvz7,
            R.string.lvl8_F3qvz8,
            R.string.lvl8_F3qvz9,
    };
    //lvl9
    final int[] quest9={
            R.string.lvl9_qvz1,
            R.string.lvl9_qvz2,
            R.string.lvl9_qvz3,
            R.string.lvl9_qvz4,
            R.string.lvl9_qvz5,
            R.string.lvl9_qvz6,
            R.string.lvl9_qvz7,
            R.string.lvl9_qvz8,
            R.string.lvl9_qvz9,
    };

    final int[] f1_Quest9={
            R.string.lvl9_F1qvz1,
            R.string.lvl9_F1qvz2,
            R.string.lvl9_F1qvz3,
            R.string.lvl9_F1qvz4,
            R.string.lvl9_F1qvz5,
            R.string.lvl9_F1qvz6,
            R.string.lvl9_F1qvz7,
            R.string.lvl9_F1qvz8,
            R.string.lvl9_F1qvz9,
    };

    final int[] f2_Quest9={
            R.string.lvl9_F2qvz1,
            R.string.lvl9_F2qvz2,
            R.string.lvl9_F2qvz3,
            R.string.lvl9_F2qvz4,
            R.string.lvl9_F2qvz5,
            R.string.lvl9_F2qvz6,
            R.string.lvl9_F2qvz7,
            R.string.lvl9_F2qvz8,
            R.string.lvl9_F2qvz9,
    };

    final int[] f3_Quest9={
            R.string.lvl9_F3qvz1,
            R.string.lvl9_F3qvz2,
            R.string.lvl9_F3qvz3,
            R.string.lvl9_F3qvz4,
            R.string.lvl9_F3qvz5,
            R.string.lvl9_F3qvz6,
            R.string.lvl9_F3qvz7,
            R.string.lvl9_F3qvz8,
            R.string.lvl9_F3qvz9,
    };
    //lvl10
    final int[] quest10={
            R.string.lvl10_qvz1,
            R.string.lvl10_qvz2,
            R.string.lvl10_qvz3,
            R.string.lvl10_qvz4,
            R.string.lvl10_qvz5,
            R.string.lvl10_qvz6,
            R.string.lvl10_qvz7,
            R.string.lvl10_qvz8,
            R.string.lvl10_qvz9,
    };

    final int[] f1_Quest10={
            R.string.lvl10_F1qvz1,
            R.string.lvl10_F1qvz2,
            R.string.lvl10_F1qvz3,
            R.string.lvl10_F1qvz4,
            R.string.lvl10_F1qvz5,
            R.string.lvl10_F1qvz6,
            R.string.lvl10_F1qvz7,
            R.string.lvl10_F1qvz8,
            R.string.lvl10_F1qvz9,
    };

    final int[] f2_Quest10={
            R.string.lvl10_F2qvz1,
            R.string.lvl10_F2qvz2,
            R.string.lvl10_F2qvz3,
            R.string.lvl10_F2qvz4,
            R.string.lvl10_F2qvz5,
            R.string.lvl10_F2qvz6,
            R.string.lvl10_F2qvz7,
            R.string.lvl10_F2qvz8,
            R.string.lvl10_F2qvz9,
    };

    final int[] f3_Quest10={
            R.string.lvl10_F3qvz1,
            R.string.lvl10_F3qvz2,
            R.string.lvl10_F3qvz3,
            R.string.lvl10_F3qvz4,
            R.string.lvl10_F3qvz5,
            R.string.lvl10_F3qvz6,
            R.string.lvl10_F3qvz7,
            R.string.lvl10_F3qvz8,
            R.string.lvl10_F3qvz9,
    };
}
