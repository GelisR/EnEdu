package com.example.enedu;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Level7 extends AppCompatActivity {

    Dialog dialog;
    Dialog dialogEnd;

    public int Question;
    public int variant;
    Array array = new Array();
    Random random = new Random();
    public int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.universal);

        TextView text_levels = findViewById(R.id.text_lvl);
        text_levels.setText(R.string.level7);

        final ImageView question_panel = (ImageView) findViewById(R.id.question_panel);
        question_panel.setClipToOutline(true);

        final TextView leftAn1 = findViewById(R.id.LeftAnswer1);
        final TextView leftAn2 = findViewById(R.id.LeftAnswer2);
        final TextView rightAn1 = findViewById(R.id.RightAnswer1);
        final TextView rightAn2 = findViewById(R.id.RightAnswer2);

        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        dialog=new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.previwedialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);

        TextView tx=(TextView) dialog.findViewById(R.id.lvl1);
        tx.setText(R.string.lvl7);
        TextView textdesct =(TextView)dialog.findViewById(R.id.theory);
        textdesct.setText(R.string.level_7);

        TextView btnClose=(TextView) dialog.findViewById(R.id.btnclose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Level7.this, GameLevels.class);
                    startActivity(intent);
                    finish();
                }catch(Exception e){

                }
                dialog.dismiss();
            }
        });

        Button btnContinue = (Button) dialog.findViewById(R.id.button_continue);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();

        //___________________________________________
        dialogEnd=new Dialog(this);
        dialogEnd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogEnd.setContentView(R.layout.end_dialog);
        dialogEnd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogEnd.setCancelable(false);

        TextView tx1=(TextView) dialogEnd.findViewById(R.id.lvl1);
        tx1.setText(R.string.lvl7);
        TextView textdesct1 =(TextView)dialogEnd.findViewById(R.id.congratulations);
        textdesct1.setText(R.string.conc7);

        TextView btnClose2=(TextView) dialogEnd.findViewById(R.id.btnclose);
        btnClose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Level7.this, GameLevels.class);
                    startActivity(intent);
                    finish();
                }catch(Exception e){

                }
                dialogEnd.dismiss();
            }
        });

        Button btnContinue2 = (Button) dialogEnd.findViewById(R.id.button_continue);
        btnContinue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Level7.this, Level8.class);
                    startActivity(intent);
                    finish();
                }catch(Exception e){

                }
                dialogEnd.dismiss();
            }
        });

        Button btn_back=(Button) findViewById(R.id.back_button);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Level7.this, GameLevels.class);
                    startActivity(intent);
                    finish();
                }catch(Exception e){

                }
            }
        });

        int[] progress={
                R.id.point1,R.id.point2,R.id.point3,R.id.point4,R.id.point5,
                R.id.point6,R.id.point7,R.id.point8,R.id.point9,R.id.point10,
        };

        final Animation a = AnimationUtils.loadAnimation(Level7.this, R.anim.alpha);

        Question = random.nextInt(9);
        variant = random.nextInt(4);
        switch (variant){
            case(0):
                leftAn1.setText(array.quest7[Question]);
                leftAn2.setText(array.f1_Quest7[Question]);
                rightAn1.setText(array.f2_Quest7[Question]);
                rightAn2.setText(array.f3_Quest7[Question]);
                break;
            case(1):
                rightAn2.setText(array.f3_Quest7[Question]);
                rightAn1.setText(array.f2_Quest7[Question]);
                leftAn1.setText(array.f1_Quest7[Question]);
                leftAn2.setText(array.quest7[Question]);
                break;
            case(2):
                leftAn1.setText(array.f3_Quest7[Question]);
                leftAn2.setText(array.f2_Quest7[Question]);
                rightAn1.setText(array.quest7[Question]);
                rightAn2.setText(array.f1_Quest7[Question]);
                break;
            case(3):
                leftAn1.setText(array.f2_Quest7[Question]);
                leftAn2.setText(array.f3_Quest7[Question]);
                rightAn1.setText(array.f1_Quest7[Question]);
                rightAn2.setText(array.quest7[Question]);
                break;
        }
        question_panel.setImageResource(array.images7[Question]);

        leftAn1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    leftAn2.setEnabled(false);
                    rightAn1.setEnabled(false);
                    rightAn2.setEnabled(false);

                    if(leftAn1.getText()==getResources().getString(array.quest7[Question])){
                        leftAn1.setBackgroundResource(R.drawable.true_ansv_button);
                    }else{
                        leftAn1.setBackgroundResource(R.drawable.false_ansv_button);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    leftAn1.setBackgroundResource(R.drawable.btn_gamelevels);
                    if(leftAn1.getText()==getResources().getString(array.quest7[Question])){
                        if(count<10){
                            count++;
                        }

                        for(int i=0;i<10;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else{
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count-=2;
                            }
                        }
                        for(int i=0;i<9;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }

                    if(count==10){
                        //exit from lvl
                        SharedPreferences save = getSharedPreferences("Save",MODE_PRIVATE);
                        final int level=save.getInt("Level",1);
                        if(level>7){

                        }else{
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level",8);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else{
                        Question = random.nextInt(9);
                        variant = random.nextInt(4);
                        switch (variant){
                            case(0):
                                leftAn1.setText(array.quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f1_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f3_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(1):
                                rightAn2.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                leftAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                leftAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(2):
                                leftAn1.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f1_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(3):
                                leftAn1.setText(array.f2_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f3_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                        }
                        question_panel.setImageResource(array.images7[Question]);
                        question_panel.startAnimation(a);

                        leftAn2.setEnabled(true);
                        rightAn1.setEnabled(true);
                        rightAn2.setEnabled(true);
                    }
                }

                return true;
            }
        });
        leftAn2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    leftAn1.setEnabled(false);
                    rightAn1.setEnabled(false);
                    rightAn2.setEnabled(false);

                    if(leftAn2.getText()==getResources().getString(array.quest7[Question])){
                        leftAn2.setBackgroundResource(R.drawable.true_ansv_button);
                    }else{
                        leftAn2.setBackgroundResource(R.drawable.false_ansv_button);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    leftAn2.setBackgroundResource(R.drawable.btn_gamelevels);
                    if(leftAn2.getText()==getResources().getString(array.quest7[Question])){
                        if(count<10){
                            count++;
                        }

                        for(int i=0;i<10;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else{
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count-=2;
                            }
                        }
                        for(int i=0;i<9;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }

                    if(count==10){
                        //exit from lvl
                        SharedPreferences save = getSharedPreferences("Save",MODE_PRIVATE);
                        final int level=save.getInt("Level",1);
                        if(level>7){

                        }else{
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level",8);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else{
                        Question = random.nextInt(9);
                        variant = random.nextInt(4);
                        switch (variant){
                            case(0):
                                leftAn1.setText(array.quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f1_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f3_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(1):
                                rightAn2.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                leftAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                leftAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(2):
                                leftAn1.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f1_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(3):
                                leftAn1.setText(array.f2_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f3_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                        }
                        question_panel.setImageResource(array.images7[Question]);
                        question_panel.startAnimation(a);

                        leftAn1.setEnabled(true);
                        rightAn1.setEnabled(true);
                        rightAn2.setEnabled(true);
                    }
                }

                return true;
            }
        });
        rightAn1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    leftAn1.setEnabled(false);
                    leftAn2.setEnabled(false);
                    rightAn2.setEnabled(false);

                    if(rightAn1.getText()==getResources().getString(array.quest7[Question])){
                        rightAn1.setBackgroundResource(R.drawable.true_ansv_button);
                    }else{
                        rightAn1.setBackgroundResource(R.drawable.false_ansv_button);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    rightAn1.setBackgroundResource(R.drawable.btn_gamelevels);
                    if(rightAn1.getText()==getResources().getString(array.quest7[Question])){
                        if(count<10){
                            count++;
                        }

                        for(int i=0;i<10;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else{
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count-=2;
                            }
                        }
                        for(int i=0;i<9;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }

                    if(count==10){
                        //exit from lvl
                        SharedPreferences save = getSharedPreferences("Save",MODE_PRIVATE);
                        final int level=save.getInt("Level",1);
                        if(level>7){

                        }else{
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level",8);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else{
                        Question = random.nextInt(9);
                        variant = random.nextInt(4);
                        switch (variant){
                            case(0):
                                leftAn1.setText(array.quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f1_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f3_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(1):
                                rightAn2.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                leftAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                leftAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(2):
                                leftAn1.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f1_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(3):
                                leftAn1.setText(array.f2_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f3_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                        }
                        question_panel.setImageResource(array.images7[Question]);
                        question_panel.startAnimation(a);

                        leftAn1.setEnabled(true);
                        leftAn2.setEnabled(true);
                        rightAn2.setEnabled(true);
                    }
                }

                return true;
            }
        });
        rightAn2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    leftAn1.setEnabled(false);
                    leftAn2.setEnabled(false);
                    rightAn1.setEnabled(false);

                    if(rightAn2.getText()==getResources().getString(array.quest7[Question])){
                        rightAn2.setBackgroundResource(R.drawable.true_ansv_button);
                    }else{
                        rightAn2.setBackgroundResource(R.drawable.false_ansv_button);
                    }
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    rightAn2.setBackgroundResource(R.drawable.btn_gamelevels);
                    if(rightAn2.getText()==getResources().getString(array.quest7[Question])){
                        if(count<10){
                            count++;
                        }

                        for(int i=0;i<10;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else{
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count-=2;
                            }
                        }
                        for(int i=0;i<9;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }

                        for(int i=0; i<count;i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }

                    if(count==10){
                        //exit from lvl
                        SharedPreferences save = getSharedPreferences("Save",MODE_PRIVATE);
                        final int level=save.getInt("Level",1);
                        if(level>7){

                        }else{
                            SharedPreferences.Editor editor = save.edit();
                            editor.putInt("Level",8);
                            editor.commit();
                        }
                        dialogEnd.show();
                    }else{
                        Question = random.nextInt(9);
                        variant = random.nextInt(4);
                        switch (variant){
                            case(0):
                                leftAn1.setText(array.quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f1_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f3_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(1):
                                rightAn2.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                rightAn1.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                leftAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                leftAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(2):
                                leftAn1.setText(array.f3_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f2_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.f1_Quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                            case(3):
                                leftAn1.setText(array.f2_Quest7[Question]);
                                leftAn1.startAnimation(a);
                                leftAn2.setText(array.f3_Quest7[Question]);
                                leftAn2.startAnimation(a);
                                rightAn1.setText(array.f1_Quest7[Question]);
                                rightAn1.startAnimation(a);
                                rightAn2.setText(array.quest7[Question]);
                                rightAn2.startAnimation(a);
                                break;
                        }
                        question_panel.setImageResource(array.images7[Question]);
                        question_panel.startAnimation(a);

                        leftAn1.setEnabled(true);
                        leftAn2.setEnabled(true);
                        rightAn1.setEnabled(true);
                    }
                }

                return true;
            }
        });
    }

    @Override
    public void onBackPressed(){
        try{
            Intent intent = new Intent(Level7.this, GameLevels.class);
            startActivity(intent);
            finish();
        }catch(Exception e){

        }
    }
}